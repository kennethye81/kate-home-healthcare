# Kate 知识库 — 待人工修复死链清单

*生成于 2026-07-09 22:44*
*自动修复: 27 条 | 待人工: 150 条*

| 引用文件 | 死链 | 说明 |
|:----|:----|:-----|
| Countries/瑞典/00-概览.md | `04-RPM与技术设备.md` | 文件/页面不存在 |
| Countries/瑞典/00-概览.md | `05-临床证据.md` | 文件/页面不存在 |
| Countries/瑞典/00-概览.md | `06-劳动力市场.md` | 文件/页面不存在 |
| Countries/韩国/00-概览.md | `01-政策与法律法规` | 文件/页面不存在 |
| Countries/韩国/00-概览.md | `02-支付体系` | 文件/页面不存在 |
| Countries/韩国/00-概览.md | `04-RPM与技术设备` | 文件/页面不存在 |
| Countries/韩国/00-概览.md | `05-临床证据` | 文件/页面不存在 |
| Countries/韩国/00-概览.md | `06-劳动力市场` | 文件/页面不存在 |
| Countries/香港/04-RPM与技术设备.md | `03-头部机构` | 文件/页面不存在 |
| Countries/中国/02-支付体系.md | `00-概览.md` | 文件/页面不存在 |
| Countries/中国/02-支付体系.md | `01-政策与法律法规.md` | 文件/页面不存在 |
| Countries/中国/01-政策与法律法规.md | `00-概览.md` | 文件/页面不存在 |
| Countries/中国/01-政策与法律法规.md | `02-支付体系.md` | 文件/页面不存在 |
| Countries/美国/02-支付体系.md | `00-概览.md` | 文件/页面不存在 |
| Countries/美国/02-支付体系.md | `01-政策与法律法规` | 文件/页面不存在 |
| Countries/美国/02-支付体系.md | `06-劳动力市场.md` | 文件/页面不存在 |
| Countries/美国/03-头部机构/Contessa.md | `reports/2026-07-03-contessa-hah-27dim.md` | 文件/页面不存在 |
| Countries/澳大利亚/01-政策与法律法规.md | `00-概览` | 文件/页面不存在 |
| Countries/澳大利亚/01-政策与法律法规.md | `../../Topics/跨国HaH对标` | 文件/页面不存在 |
| Countries/澳大利亚/02-竞品对比.md | `../../Topics/跨国HaH对标` | 文件/页面不存在 |
| Countries/澳大利亚/00-概览.md | `../../Topics/跨国HaH对标.md` | 文件/页面不存在 |
| Countries/澳大利亚/03-头部机构/Regis Healthcare.md | `../Estia Health` | 文件/页面不存在 |
| Countries/荷兰/00-概览.md | `01-政策与法律法规.md` | 文件/页面不存在 |
| Countries/荷兰/00-概览.md | `02-支付体系.md` | 文件/页面不存在 |
| Countries/荷兰/00-概览.md | `04-RPM与技术设备.md` | 文件/页面不存在 |
| Countries/荷兰/00-概览.md | `05-临床证据.md` | 文件/页面不存在 |
| Countries/荷兰/00-概览.md | `06-劳动力市场.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `06-劳动力市场.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `01-政策与法律法规.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `02-支付体系.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `05-临床证据.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `06-劳动力市场.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `04-RPM与技术设备.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `01-政策与法律法规.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `02-支付体系.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `04-RPM与技术设备.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `05-临床证据.md` | 文件/页面不存在 |
| Countries/法国/00-概览.md | `06-劳动力市场.md` | 文件/页面不存在 |
| Countries/以色列/00-概览.md | `04-RPM与技术设备.md` | 文件/页面不存在 |
| Countries/以色列/00-概览.md | `05-临床证据.md` | 文件/页面不存在 |
| Countries/以色列/00-概览.md | `06-劳动力市场.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../../Topics/RPM硬件对比.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../../Countries/香港/03-头部机构/Bamboos百本医护.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../../Countries/香港/03-头部机构/Evercare.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `##5.3 里程碑决策模板` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `##5.1 会议纪要模板` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../战略与融资/00-战略规划/2026-Q3战略.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../../Topics/启动路径.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../../Countries/香港/03-头部机构/{{竞品}}` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../../Topics/RPM设备商全景.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../05-市场与竞争/02-合作伙伴生态/` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../02-产品与临床/00-产品路线图.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../06-战略与融资/03-风险登记册.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../06-战略与融资/00-战略规划/2026-Q3战略.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/System/Templates/会议纪要` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/System/Templates/竞品跟踪` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/System/Templates/里程碑决策` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/01-公司概况/00-公司简介` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/01-公司概况/02-组织架构图` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/01-公司概况/04-投资者关系/00-股东列表` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/02-产品与临床/00-产品路线图` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/02-产品与临床/03-患者旅程` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/02-产品与临床/04-质量指标` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/03-技术与RPM/00-技术架构` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/03-技术与RPM/02-RPM设备管理` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/03-技术与RPM/03-数据平台` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/04-商业模式与财务/00-商业模式画布` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/04-商业模式与财务/03-财务模型` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/04-商业模式与财务/04-收入跟踪` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/05-市场与竞争/00-市场研究` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/05-市场与竞争/01-竞品跟踪` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/05-市场与竞争/03-客户之声` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/06-战略与融资/00-战略规划` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/06-战略与融资/01-融资进展` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/06-战略与融资/03-风险登记册` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/07-运营与团队/00-团队OKR` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/07-运营与团队/03-会议纪要` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `iHomeCare/07-运营与团队/04-决策日志` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../iHomeCare/05-市场与竞争/01-竞品跟踪/Bamboos百本医护` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../iHomeCare/05-市场与竞争/00-市场研究/香港HaH-TAM-SAM-SOM` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../iHomeCare/04-商业模式与财务/02-支付方对接/保险对接清单` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v2.md | `../../Countries/香港/02-支付体系.md` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `wikilink` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/Companies/Bamboos-百本医护` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/Companies/Evercare` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/Companies/EDEN-HOME` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/02-政策` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/05-RPM` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/06-劳动力` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/新加坡/01-概览` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Topics/居家医疗政策对比` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/07-劳动力` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/04-头部机构` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Topics/HaH支付模型/01-支付模式总览` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `wikilink` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `wikilink` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `wikilink` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/References/27维度评估模板` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/References/支付模型对比表` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `交叉引用相关文档` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/01-概览` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/Competitors/01-竞品对标全景图` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Topics/HaH支付模型/01-支付模式总览` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/Company/04-保密规则` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/References/27维度评估模板` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/Companies/[竞品名` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/03-市场` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Topics/HaH支付模型/01-支付模式总览` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/References/临床证据库索引` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Topics/居家医疗政策对比/02-支付模型对比` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/Product/04-产品路线图` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/Company/05-财务模型与估值` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/Investors/01-投资者问答日志` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/03-市场` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Topics/HaH支付模型/01-支付模式总览` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/Competitors/01-竞品对标全景图` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/Company/03-核心团队与顾问` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/Company/05-财务模型与估值` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/References/支付模型对比表` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/Policy/01-香港HaH政策跟踪` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/02-政策` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `尽职调查材料` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `运营数据` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `iHomeCare/Company/02-股权与融资史` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `wikilink` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `目标` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `wikilink` | 文件/页面不存在 |
| Topics/iHomeCare知识分区架构设计-v3.md | `Countries/香港/03-市场` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v2.md | `...` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v2.md | `路径` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v2.md | `reports/xxx.md` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v2.md | `reports/xxx.md` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v2.md | `path` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v2.md | `path` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v2.md | `path` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v2.md | `新页面` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v2.md | `path` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v2.md | `目标路径` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `reports/xxx` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `reports/\2.md` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `reports/xxx.md` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `wikilink` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `wikilink` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `相对路径` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `旧路径` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `新路径` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `reports/\2.md` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `Countries/国家名/xxx.md` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `绝对路径.md` | 文件/页面不存在 |
| Topics/双工具协同运维手册-v3.md | `reports/\2.md` | 文件/页面不存在 |

---
### 修复指南

1. 检查链接指向的文件或目录是否存在
2. 常见问题: 文件名空格差异、缺少 .md 后缀、相对路径层级错误
3. 如果是故意留空(预留Topic)，请在该页面添加 `tags: [stub, reserved]`
4. 修复后运行 `python3 ~/.hermes/scripts/kate-lint.py` 验证