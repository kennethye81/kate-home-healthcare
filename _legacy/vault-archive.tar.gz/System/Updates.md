---
tags: [dashboard, updates, changelog]
created: 2026-07-05
updated: 2026-07-05
---

# 📋 Kate 知识库每日更新

> 自动记录每天写入知识库的新信息 — 按国家/专题分组
> 最后更新：2026-07-05 00:30

---

<!-- 以下内容由 kb_pipeline.py --changelog 每日自动生成 -->
<!-- CHANGELOG_START -->
## 2026-07-07

**总更新：** 19 个页面

### 🌏 国家

- [[Countries/中国/01-政策与法律法规.md|中国 — 01-政策与法律法规.md]]
- [[Countries/中国/00-概览.md|中国 — 00-概览.md]]
- [[Countries/日本/00-概览.md|日本 — 00-概览.md]]
- [[Countries/美国/02-支付体系.md|美国 — 02-支付体系.md]]
- [[Countries/美国/01-政策与法律法规.md|美国 — 01-政策与法律法规.md]]
- [[Countries/美国/03-头部机构/Amedisys.md|美国 — 03-头部机构/Amedisys.md]]
- [[Countries/英国/03-头部机构/Clinitouch.md|英国 — 03-头部机构/Clinitouch.md]]
- [[Countries/英国/03-头部机构/DOC@HOME.md|英国 — 03-头部机构/DOC@HOME.md]]
- [[Countries/英国/03-头部机构/Huma.md|英国 — 03-头部机构/Huma.md]]
- [[Countries/英国/03-头部机构/Birdie.md|英国 — 03-头部机构/Birdie.md]]
- [[Countries/英国/03-头部机构/Cera.md|英国 — 03-头部机构/Cera.md]]
- [[Countries/英国/03-头部机构/Elder.md|英国 — 03-头部机构/Elder.md]]
- [[Countries/英国/03-头部机构/Inhealthcare.md|英国 — 03-头部机构/Inhealthcare.md]]
- [[Countries/英国/03-头部机构/Isansys.md|英国 — 03-头部机构/Isansys.md]]
- [[Countries/英国/03-头部机构/Luscii.md|英国 — 03-头部机构/Luscii.md]]
- [[Countries/英国/03-头部机构/Feebris.md|英国 — 03-头部机构/Feebris.md]]
- [[Countries/英国/03-头部机构/Lottie.md|英国 — 03-头部机构/Lottie.md]]
- [[Countries/英国/03-头部机构/Doccla.md|英国 — 03-头部机构/Doccla.md]]
- [[Countries/英国/03-头部机构/Whzan.md|英国 — 03-头部机构/Whzan.md]]
<!-- CHANGELOG_END -->
