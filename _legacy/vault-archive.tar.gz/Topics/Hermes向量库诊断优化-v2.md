# Hermes 知识存储架构诊断与优化方案

**文档版本**：v1.0  
**编写日期**：2026-07-05  
**范围**：Kate-Strategist 专案下 Hermes Agent 知识存储全链路  
**诊断基准**：基于真实配置（memory/membase、Obsidian Vault、entity_fact.json）及已知痛点

---

## 一、现状诊断：当前三层存储架构

### 1.1 架构全景图（文字描述）

```
┌──────────────────────────────────────────────────────────┐
│                     L1 — Runtime Memory                    │
│   (membase provider / 50KB char limit / 5KB user profile)  │
│   • 会话窗口期关键偏好、事实摘要                            │
│   • flush_min_turns=6 批量落盘                              │
│   • 写入需 Agent 主动触发，无语义召回能力                     │
│   • 位于 Kate-Strategist profile 内                          │
├──────────────────────────────────────────────────────────┤
│                     L2 — FactStore                          │
│   (entity_fact.json / 147 entities / 48,654 facts)          │
│   • 代数推理式结构化记忆（fact_store 工具）                   │
│   • 实体-属性-值三元组，支持精确查询 & 代数聚合               │
│   • 无向量索引 → 不支持语义模糊匹配                          │
│   • 更新依赖 kb_pipeline.py 每日 sync                         │
├──────────────────────────────────────────────────────────┤
│               L3 — Disk KB (Obsidian Vault)                 │
│   (1.3MB / ~190 pages markdown)                             │
│   • 本地 Obsidian Vault 全量知识库                          │
│   • 无结构化索引、无 embedding、无切片                       │
│   • 仅通过 kb_pipeline.py cron 每日同步到硬盘                │
│   • 内容加载需手动搜索或直接读文件                            │
└──────────────────────────────────────────────────────────┘
```

### 1.2 每层能力边界评估

| 层级 | 存储形式 | 容量 | 查询方式 | 语义理解 | 实时性 | 自动化程度 |
|------|---------|------|---------|---------|-------|-----------|
| **L1 Memory** | membase JSON | 50KB | 精确 key lookup | ❌ 无 | 中（6轮Flush） | 中（自动flush） |
| **L2 FactStore** | entity_fact.json | ~200KB+ | fact_store 工具精确查询 | ❌ 代数推理，无语义 | 低（每日 sync） | 中（cron驱动） |
| **L3 Disk KB** | Markdown 文件 | 1.3MB | 文件系统+手动搜索 | ❌ 纯文本 | 低（每日 sync） | 低（手动触发） |

**关键发现**：三层之间**无语义桥梁**。Memory 无法感知 KB 内容，FactStore 无法模糊匹配，KB 无法被自动检索。数据在层层下沉时，召回成本指数级上升。

---

## 二、痛点分析：分层效率损失点

### 2.1 调研效率损失（L1 ↔ L3 层间断裂）

| # | 痛点 | 所属层次断裂 | 具体表现 | 每次操作时间成本估计 |
|---|------|-------------|---------|-------------------|
| 1 | **调研时无语义召回** | L1↛L3 | 用户询问 KB 内容时，Agent 无法自动判断哪些文档相关，必须多引擎手动搜索或逐文件 grep | 3-8 分钟/次 |
| 2 | **Memory 容量瓶颈** | L1 内部 | 50KB char limit 意味着只能存约 8K-12K tokens 的内容，关键调研发现的上下文被频繁裁剪 | 高频场景下每分钟累积损失 |
| 3 | **报告归档需手动触发** | L2↛L3 | auto_indexer.py 无自动触发机制，生成报告后需用户手动运行入库命令 | 2-5 分钟/次 |
| 4 | **矛盾检测不实时** | L2 内部 | 矛盾检测依赖每周二 cron 扫描 entity_fact.json，新写入的事实需等最长 7 天才能被检查 | ≤7 天延迟 |

### 2.2 知识管理效率损失

| # | 痛点 | 所属层次断裂 | 具体表现 | 每次操作时间成本估计 |
|---|------|-------------|---------|-------------------|
| 5 | **KB 变更无法自动索引** | L3 内部 | Obsidian Vault 文件修改后需等每日 cron 同步，新增内容在当天内不可用 | ≤24 小时延迟 |
| 6 | **entity_fact 无版本历史** | L2 内部 | 48,654 条事实点无变更跟踪，回滚错误事实只能手动恢复 | 10-30 分钟/次 |
| 7 | **跨文档关联缺失** | L3 内部 | 190 页 markdown 间无自动超链接或关系图谱，Agent 无法感知文档间语义关联 | — |
| 8 | **无 RAG 就绪标注** | L3 内部 | KB 文档未切片、未加元数据标签，无法直接接入向量检索管道 | — |

### 2.3 综合效率损失汇总

- **每次调研会话额外开销**：10-20 分钟（搜索+验证+手工整理）
- **每日累积效率折损**：约 30-60 分钟
- **知识一致性问题**：每周约 2-3 次需手动修复的事实冲突（基于矛盾扫描结果）

---

## 三、优化方案：推荐的四层存储架构

### 3.1 目标架构图（文字描述）

```
┌────────────────────────────────────────────────────────────────────┐
│               L0 — 高频 Memory（现有 membase 升级）                    │
│   • 容量扩充至 100-200KB                                          │
│   • 新增「调研上下文缓冲区」（临时保存当前会话的相关KB片段）           │
│   • 集成 fact_store 快速查询缓存                                     │
│   • 写入前路由：优先查向量层 → 命中则引用，否则Query KB              │
├────────────────────────────────────────────────────────────────────┤
│              L1 — 中频 FactStore（现有升级）                          │
│   • entity_fact.json 增加版本号 & 变更日志                            │
│   • 引入值域约束（枚举/正则/数值范围） → 减少矛盾                     │
│   • 增加批次写入校验（写入时即检查与已有事实的矛盾）                    │
├────────────────────────────────────────────────────────────────────┤
│            L2 — 向量化 KB（新增层 — 本次优化核心）                     │
│   • Obsidian Vault 文档 → 切片（chunk） → embedding → 向量库        │
│   • 支持语义检索（query → embedding → top-k 召回）                  │
│   • 每日 kb_pipeline.py 联动：同步 → 切片 → embed → upsert          │
│   • 可选后端：Chroma（本地轻量） / Qdrant（本地/容器化）              │
├────────────────────────────────────────────────────────────────────┤
│             L3 — 原始文档层（Obsidian Vault 无变化）                  │
│   • 保持原始 markdown 格式，作为「源站」                              │
│   • 新增元数据文件（_index.yaml）记录文档状态、最后索引时间、chunk数   │
└────────────────────────────────────────────────────────────────────┘
```

### 3.2 各层职责与数据流

```
用户提问
  │
  ├─→ L0 Memory: 检查是否已有答案（精确 key + 向量缓存命中）
  │     │ 命中 → 直接返回
  │     └ 未命中 → 下钻
  │
  ├─→ L1 FactStore: 精确事实查询（代数推理）
  │     │ 命中 → 返回 + 写入 L0 缓存
  │     └ 未命中 → 下钻
  │
  ├─→ L2 向量库: 语义检索 KB 内容
  │     │ 命中 → 返回 top-5 chunks + 写入 L0 缓存
  │     └ 未命中 → 下钻
  │
  └─→ L3 原始 KB: 文件系统兜底读取（罕见）
        → 返回 + 触发异步索引到 L2
```

### 3.3 优化项一览表

| 优化项 | 所属层次 | 预期效果 | 投入成本 |
|--------|---------|---------|---------|
| Memory 容量扩容 | L0 | 减少上下文裁剪频率，提升会话连贯性 | 低（修改配置参数） |
| 调研上下文缓冲区 | L0 | 当前会话中重复 KB 查询减少 60% | 中（需编写缓存逻辑） |
| fact_store 值域约束 | L1 | 矛盾率降低约 80% | 低（增加 schema 校验） |
| 实时矛盾检测 | L1 | 发现矛盾从 7 天缩短到秒级 | 中（写入时增量校验） |
| **向量化 KB（核心）** | L2 | 语义召回实现，调研效率提升 5-10x | 高（详见第四部分） |
| _index.yaml 元数据 | L3 | 文档状态可追踪，索引可见 | 低（额外元文件） |
| 文档自动切片 | L2↛L3 | KB 知识可被粒度检索 | 中（切片策略需调优） |

---

## 四、向量化方案（外部集成思路）

> **说明**：当前 Hermes 原生不支持向量库/embedding/RAG，以下方案为**外部集成**思路，通过 Hermes Tools + Cron + 外部脚本实现。

### 4.1 架构概览

```
┌──────────────────────────────────────────────┐
│              kb_pipeline.py (cron 每日)         │
│                                              │
│  1. rsync Obsidian Vault 变更                   │
│  2. 检测新增/修改文件                          │
│  3. 调用 chunk_docs.py → 切片 markdown        │
│     - 按标题层级切片（## 为 chunk 边界）         │
│     - 每 chunk 256-512 tokens                 │
│     - 保留元数据（来源文件、标题、路径）          │
│  4. 调用 embed_chunks.py → 生成向量           │
│     - 本地模型：all-MiniLM-L6-v2 (384维)       │
│       或 BGE-base-zh-v1.5 (适用于中文场景)       │
│     - 通过 sentence-transformers 本地运行       │
│     - 无 API 调用，零网络延迟                   │
│  5. 调用 upsert_vector_db.py → 写入向量库     │
│     - Chroma: 本地文件系统持久化，零运维         │
│     或 Qdrant: Docker 容器，支持过滤+混合检索    │
│  6. 更新 _index.yaml                           │
└──────────────────────────────────────────────┘
```

### 4.2 技术选型对比

| 组件 | 选项A：Chroma（推荐入门） | 选项B：Qdrant（推荐进阶） |
|------|------------------------|------------------------|
| **部署方式** | pip install → 本地文件 | Docker 容器 / 本地二进制 |
| **持久化** | SQLite 文件（~几MB） | RocksDB 持久化 |
| **检索能力** | 语义检索 + metadata 过滤 | 语义 + 过滤 + 混合搜索（BM25） |
| **适用场景** | 个人/小团队 < 10万 chunks | 团队级别 > 10万 chunks |
| **运维成本** | 0（纯文件） | 低（需启动容器） |
| **中文支持** | 依赖 embedding 模型 | 依赖 embedding 模型 |
| **内存占用** | ~256MB | ~512MB-1GB |
| **推荐度** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ |

### 4.3 Embedding 模型方案

| 模型 | 维度 | 语言 | 大小 | 速度 | 推荐场景 |
|------|------|------|------|------|---------|
| **BAAI/bge-small-zh-v1.5** | 384 | 中文优先 | ~33MB | ⚡ 极快 | **首选 — 速度快，中文效果好** |
| **sentence-transformers/all-MiniLM-L6-v2** | 384 | 英文 | ~80MB | ⚡ 快 | KB 英文为主时 |
| **intfloat/multilingual-e5-small** | 384 | 多语言 | ~118MB | ⚡ 快 | 中英混杂场景 |
| **BAAI/bge-base-zh-v1.5** | 768 | 中文优先 | ~110MB | 🐢 中等 | 精度优先场景 |

**推荐**：先用 `bge-small-zh-v1.5`（33MB，384维），在 MacBook 上 CPU 推理，190页文档嵌入总耗时 < 30 秒。

### 4.4 与 Hermes Tool 集成方式

Hermes 端新增一个自定义 tool `kb_search`，实现方式：

```python
# kb_search_tool.py — 注册为 Hermes Tool
class KBSearchTool:
    name = "kb_search"
    description = "语义搜索本地知识库（Obsidian Vault），返回最相关的文档片段"

    def __call__(self, query: str, top_k: int = 5):
        # 1. 用本地 embedding 模型将 query 转为向量
        query_vec = local_embed_model.encode(query)

        # 2. 查询本地 Chroma/Qdrant 向量库
        results = vector_db.search(query_vec, top_k=top_k)

        # 3. 返回 markdown 格式的片段列表
        return self.format_results(results)
```

注册方式：在 Kate-Strategist profile 的 tools 目录下放置该工具，重启会话后即可在 Agent 中自动调用。

### 4.5 切片策略建议

```
文档结构示例（Obsidian Markdown）：
───────
# 标题1
内容段落...
## 子标题1.1
子内容...
## 子标题1.2
另一子内容...
───────

推荐切片策略：
- 主层级切片：以 ## 或 ### 为边界，每 chunk 包含该标题及其正文
- 回退策略：无标题段落 → 按 512 字符自然断句
- 重叠策略：chunk 间重叠 10% 字符，避免边界语义断裂
- 元数据：每个 chunk 携带 {source_file, title, headings_chain, chunk_index}
```

---

## 五、实施路径

### 5.1 阶段总览

| 阶段 | 周期 | 核心目标 | 预估人力 | 预估成本 |
|------|------|---------|---------|---------|
| **P0 — 立即可做** | 1-2天 | 零成本效率提升：Memory扩容 + FactStore约束 + 实时检测 | 单人 2天 | $0 |
| **P1 — 核心建设** | 1-2周 | 向量化KB上线：切片 + Embedding + Chroma + kb_search Tool | 单人 5-10天 | $0（纯本地） |
| **P2 — 中长期优化** | 1-3月 | 进阶：Qdrant迁移 + 增量索引 + RAG链路 + 知识图谱 | 单人/周期间断 | $0-$50/月（如用云API） |

---

### 5.2 P0 — 立即可做（1-2天）

#### 操作步骤

**步骤 1：Memory 扩容与配置优化**
- 修改 Kate-Strategist profile 的 config.yaml：
  ```yaml
  memory:
    memory_char_limit: 200000    # 从 50KB → 200KB
    user_char_limit: 10000       # 从 5KB → 10KB
    flush_min_turns: 4           # 从 6 → 4，更频繁落盘
  ```
- **预期效果**：会话上下文容纳量提升 4x，关键信息裁剪频率降低
- **成本**：$0，仅修改配置

**步骤 2：FactStore 值域约束与写入校验**
- 为 entity_fact.json 增加 schema 文件 `fact_schema.yaml`：
  ```yaml
  entity_types:
    person:
      properties:
        name: { type: string, required: true }
        birth_year: { type: integer, range: [1900, 2026] }
        alias: { type: string, unique_in_entity: true }
    technology:
      properties:
        name: { type: string, required: true }
        category: { enum: ["ML", "Infra", "Tool", "Framework"] }
  ```
- 修改 `kb_pipeline.py` 中写入 entity_fact 的逻辑，增加写入时矛盾校验
- **预期效果**：矛盾写入即时拒绝而非等周二扫描，矛盾率降 80%
- **成本**：$0，单文件改动

**步骤 3：auto_indexer.py 自动触发**
- 增加 cron 配置（在 report_generated 目录放置 watcher）：
  ```bash
  # 每分钟检查是否有新报告产生
  * * * * * /Users/kennethye/.hermes/profiles/kate-strategist/cron/watch_report.py
  ```
- `watch_report.py` 逻辑：检测输出目录文件变更 → 自动调用 `auto_indexer.py`
- **预期效果**：报告归档无需手动操作，由文件变更事件触发
- **成本**：$0，约 50 行 Python 脚本

#### P0 预期效果汇总
| 指标 | 优化前 | 优化后 |
|------|-------|-------|
| 上下文裁剪频率 | 每 3-5 轮一段 | 每 12-20 轮一段 |
| 事实矛盾检出时间 | ≤7 天 | 实时（写入即检） |
| 报告归档操作 | 手动 → 2-5 分钟 | 自动 → 0 操作 |
| 投入成本 | — | $0，2天人力 |

---

### 5.3 P1 — 核心建设（1-2周）

#### 操作步骤

**步骤 1：环境搭建（Day 1）**
```bash
# 安装依赖
pip install chromadb sentence-transformers langchain-text-splitters

# 下载中文 embedding 模型（首次运行自动下载）
# 模型缓存 ~33MB
python -c "from sentence_transformers import SentenceTransformer; SentenceTransformer('BAAI/bge-small-zh-v1.5')"
```

- **预期效果**：向量化基础设施就绪
- **成本**：$0，约 200MB 磁盘，2小时

**步骤 2：编写切片脚本 chunk_vault.py（Day 1-2）**
- 输入：Obsidian Vault markdown 文件
- 逻辑：按 `##`/`###` 标题分层切片，保留元数据链
- 输出：JSON Lines 格式（每行一个 chunk）
  ```json
  {"id": "vault/ai-ml/transformer.md#chunk-3", "text": "...", "metadata": {"source": "transformer.md", "heading": "Attention Mechanism", "path": "/Vault/AI/transformer.md"}}
  ```
- 预计 150-200 行 Python

**步骤 3：编写向量化管道 embed_sync.py（Day 3-4）**
- 集成到现有 `kb_pipeline.py`：
  ```python
  # 每日同步流程（增量模式）
  def nightly_sync():
      changed_files = rsync_vault()            # 现有逻辑
      new_chunks = chunk_files(changed_files)   # 新增
      embeddings = embed_chunks(new_chunks)     # 新增
      vector_db.upsert(embeddings)              # 新增
      update_index_yaml()                        # 新增
  ```
- 支持增量更新（仅处理变更文件）
- 预计 200-300 行 Python

**步骤 4：构建 kb_search Hermes Tool（Day 5-6）**
- 创建 `/Users/kennethye/.hermes/profiles/kate-strategist/tools/kb_search.py`
- 实现：
  1. 加载本地 Chroma 集合
  2. query → embed → search → top-5 结果
  3. 结果格式化为带来源引用的 markdown
- 注册到 profile 的 tool 列表
- 测试：Agent 会话中输入「查找 transformer 架构相关资料」→ 返回相关 KB 片段

**步骤 5：集成测试与调优（Day 7-10）**
- 全量嵌入 190 页 KB → 验证耗时 < 30 秒
- 抽样 20 个查询测试召回准确率
- 调整 chunk 大小（256 vs 512 tokens）、重叠率（10% vs 20%）
- 确保增量更新正常工作

#### P1 预期效果汇总
| 指标 | 优化前 | 优化后 |
|------|-------|-------|
| KB 内容自动召回 | ❌ 无 | ✅ 语义检索 top-5 |
| 调研平均耗时 | 10-20 分钟/次 | 2-5 分钟/次 |
| 新内容可用延迟 | ≤24 小时 | ≤30 分钟（cron 后） |
| 投入成本 | — | $0，7-10天人力 |

---

### 5.4 P2 — 中长期优化（1-3月）

#### 操作步骤

**步骤 1：从 Chroma 迁移到 Qdrant（如需要）**
- 迁移时机：当 chunks 数量超过 50,000 或需要 BM25 混合检索时
- 操作：Docker 部署 Qdrant → 批量导出 Chroma 数据 → 导入 Qdrant
- **预期效果**：支持 metadata 过滤 + 混合搜索，检索精度 +20%
- **成本**：$0（本地 Docker），或 $5-10/月（云托管）

**步骤 2：增量索引优化**
- 使用 Obsidian 文件修改时间（mtime）而非全量 rsync
- 引入文件级 md5 校验，避免重复嵌入
- **预期效果**：每日同步从 30 秒缩短到 5 秒
- **成本**：$0，2天

**步骤 3：完整 RAG 链路（Agent 自主检索 + 推理）**
- 在 Hermes Tool 基础上增加：
  - `kb_retrieve`：检索 top-k chunks
  - `kb_answer`：检索 + 用 LLM 生成带引用的回答
  - `kb_cite`：自动在回答中标注来源文件
- **预期效果**：Agent 可自主回答「根据知识库，X 是什么？」类问题
- **成本**：$0，3-5天

**步骤 4：知识图谱层（可选）**
- 从 entity_fact.json 构建实体关系图
- 使用 NetworkX 或 Neo4j 本地实例
- 支持路径查询（「A 与 B 之间有什么关系？」）
- **预期效果**：支持多跳推理，发现间接关联
- **成本**：$0-$30/月（Docker Neo4j 资源），5-7天

**步骤 5：矛盾主动修复**
- 在 P0 实时检测基础上，增加自动修复建议
- 发现矛盾时自动生成「矛盾报告+修复建议」
- Agent 可将修复建议转换为 fact_store 写入操作
- **预期效果**：矛盾修复从手动→自动建议，修复时间从小时级→分钟级
- **成本**：$0，3天

#### P2 预期效果汇总
| 指标 | P1 优化后 | P2 优化后 |
|------|----------|----------|
| 检索精度 | 语义 top-5 | 语义+BM25 混合 + 过滤 |
| 增量同步耗时 | 30秒 | 5秒 |
| 问答形式 | 返回 chunks | 返回完整带引用答案 |
| 知识推理 | 单点查询 | 多跳图谱推理 |
| 矛盾修复 | 实时检测 | 检测+自动修复建议 |
| 投入成本 | $0 | $0-$50/月（可选云服务） |

---

## 六、风险与注意事项

### 6.1 风险矩阵

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|---------|
| Embedding 模型本地推理 CPU 性能不足 | 低 | 中 | bge-small-zh 仅 33MB，MacBook 上 190页 < 30秒 |
| Chroma 数据损坏 | 低 | 中 | 每日全量重建备份，_index.yaml 可触发恢复 |
| Obsidian Vault 格式变更 | 中 | 低 | 切片脚本适配即可，不影响原始 KB |
| Hermes 版本升级破坏 Tool 接口 | 低 | 高 | 保持 kb_search.py 与 Hermes Tool 规格对齐 |

### 6.2 注意事项

1. **隐私优先**：所有 embedding 和向量检索均在本地完成，无外部 API 调用，Obsidian Vault 内容不离开本机
2. **增量而非全量**：每日同步只处理变更文件，避免重复计算
3. **模型权衡**：bge-small-zh 优先考虑速度，如精度不足可换 bge-base-zh（110MB，评测精度 +3-5%，推理速度约慢 2x）
4. **与现有流程兼容**：所有增强不破坏现有 kb_pipeline.py cron 和 entity_fact.json 写入逻辑

---

## 附录 A：实施检查清单

### P0 检查清单
- [ ] `config.yaml` memory 段已修改
- [ ] `fact_schema.yaml` 已创建并集成到写入流程
- [ ] `watch_report.py` cron 已部署并测试
- [ ] 事实矛盾写入校验已生效

### P1 检查清单
- [ ] `chromadb` / `sentence-transformers` / `langchain-text-splitters` 已安装
- [ ] `chunk_vault.py` 脚本完成，190 页切片测试通过
- [ ] `embed_sync.py` 集成到 `kb_pipeline.py`，增量模式验证通过
- [ ] `kb_search.py` Hermes Tool 注册并可用
- [ ] 20 个抽样查询召回率 ≥ 80%
- [ ] _index.yaml 首次生成并包含所有文档状态

### P2 检查清单
- [ ] Qdrant（可选）部署并迁移完成
- [ ] 增量索引优化（mtime + md5）上线
- [ ] `kb_answer` 工具带引用生成功能完成
- [ ] 知识图谱（可选）构建完成
- [ ] 矛盾自动修复建议流程上线

---

## 附录 B：文件与目录变更汇总

```
新增文件：
  /Users/kennethye/.hermes/profiles/kate-strategist/
  ├── tools/kb_search.py               # Hermes Tool — 向量检索
  ├── scripts/chunk_vault.py           # 文档切片
  ├── scripts/embed_sync.py            # 向量化管道
  ├── schemas/fact_schema.yaml         # FactStore 值域约束
  ├── cron/watch_report.py             # 报告自动入库触发
  └── data/_index.yaml                 # KB 文档元数据索引

修改文件：
  /Users/kennethye/.hermes/profiles/kate-strategist/
  ├── config.yaml                      # memory 配置扩容
  ├── scripts/kb_pipeline.py           # 集成 embed_sync
  └── data/entity_fact.json            # 写入时配合 schema 校验
```

---

*本方案基于 Kate-Strategist 专案实际环境诊断，所有配置和代码修改均可在纯本地无网络依赖下完成。*
