---
tags: [home, dashboard]
created: 2026-07-03
updated: 2026-07-07
---

# 🏠 Kate 知识库 · 居家医疗全球研究

<mark class="conflict ours">
> 居家医疗 / 长护险 · 16 国覆盖 · 198 页面 · 全自动管线
</mark><mark class="conflict theirs">
> 居家医疗 / 长护险 · 16 国覆盖 · 208 页面 · 全自动管线
</mark>

<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- 以下统计信息由 kb_pipeline.py --refresh-home 每日自动更新 -->
<!-- STATS_BLOCK_START -->

| 指标 | 数值 | 指标 | 数值 |
|:----|:---:|:----|:---:|
| **📄 深度报告** | 150+ | **🏢 公司尽调** | 54 |
| 📝 行业研究 | 40 | 🗄️ 数据表 | 40 |
| 🔄 定期简报 | 5 | 📅 最后更新 | 2026-07-15 |

<!-- STATS_BLOCK_END -->

---

## 🌏 国家纵览

```dataview
TABLE WITHOUT ID
  link("Countries/" + key + "/00-概览",
    choice(key = "美国", "🇺🇸 美国",
    choice(key = "日本", "🇯🇵 日本",
    choice(key = "中国", "🇨🇳 中国",
    choice(key = "德国", "🇩🇪 德国",
    choice(key = "英国", "🇬🇧 英国",
    choice(key = "香港", "🇭🇰 香港",
    choice(key = "新加坡", "🇸🇬 新加坡",
    choice(key = "台湾", "🇹🇼 台湾",
    choice(key = "澳大利亚", "🇦🇺 澳大利亚",
    choice(key = "加拿大", "🇨🇦 加拿大",
    choice(key = "法国", "🇫🇷 法国",
    choice(key = "韩国", "🇰🇷 韩国",
    choice(key = "瑞典", "🇸🇪 瑞典",
    choice(key = "以色列", "🇮🇱 以色列",
    choice(key = "巴西", "🇧🇷 巴西",
    choice(key = "荷兰", "🇳🇱 荷兰",
    key))))))))))))))))) AS "国家",
  length(rows) AS "页面数",
  date(max(rows.file.mtime)) AS "最近更新"
FROM "Countries"
SORT rows.file.mtime DESC
GROUP BY split(file.folder, "/")[1] AS key
```

---

## 📚 专题知识

| 类别          | 专题                                                                                                                    |
| :---------- | :-------------------------------------------------------------------------------------------------------------------- |
| 💰 支付与融资    | [[Topics/支付对比\|支付对比]] · [[Topics/长护险融资模式对比\|长护险融资模式]] · [[Topics/支付方策略分析\|支付方策略]] · **[[Topics/跨国家对比矩阵\|🏆 16国对比]]** |
| 🏥 临床与质量    | [[Topics/临床证据\|临床证据 Meta]] · [[Topics/质量指标\|质量指标]] · [[Topics/临床协议库\|临床协议库]]                                          |
| 📡 技术与设备    | [[Topics/RPM设备商全景\|RPM 全景]] · [[Topics/技术互操作\|技术互操作]] · [[Topics/RPM硬件对比\|RPM 硬件]]                                    |
| 👩‍⚕️ 人力与运营 | [[Topics/居家医疗劳动力市场\|劳动力市场]] · [[Topics/人力经济学\|人力经济学]] · [[Topics/居家用药管理\|用药管理]]                                       |
| 🏛️ 政策与市场   | [[Topics/OECD数据\|OECD 数据]] · [[Topics/政策RSS监控\|RSS 监控]] · [[Topics/创新药政策与居家医疗协同\|创新药协同]]                              |
| 🚀 战略与投资    | [[Topics/战略规划\|战略规划]] · [[Topics/价值矩阵\|价值矩阵]] · [[Topics/启动路径\|启动路径]] · [[Topics/失败案例\|失败案例]] · [[Topics/患者旅程\|患者旅程]] |
| 📊 看板与仪表    | [[Topics/iHomeCare投资看板\|iHomeCare 看板]] · [[Topics/知识库质控巡检报告-v3\|质控巡检]] · [[Topics/双工具协同运维手册-v3\|运维手册]]                |

---

## 📋 最新动态

```dataview
TABLE file.mtime AS "更新时间", file.etags AS "标签"
FROM "Countries" OR "Topics"
SORT file.mtime DESC
LIMIT 12
```

---

## 📄 最新报告

```dataview
TABLE file.mtime AS "日期"
FROM "reports"
SORT file.mtime DESC
LIMIT 8
```

---

### 快速操作

| 新建 | 浏览 | 工具 |
|:---|:---|:---|
| 🆕 [[System/Templates/新国家\|添加国家]] · [[System/Templates/新公司\|添加公司]] · [[System/Templates/新主题\|添加主题]] | 📋 [[System/Lint/2026-07-10-lint.md|Lint 报告]] · 📡 RSS 监控 | 📅 [[daily/2026-07-10|今日日报]] · [[System/Updates|更新日志]] |

---

*数据自动维护 · 用户零手动 · 每日同步 · 周日 Lint*
